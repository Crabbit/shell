#!/bin/bash

for command_name in name
do
	echo $command_name
done
