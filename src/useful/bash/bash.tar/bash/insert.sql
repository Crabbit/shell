insert into bash_man(id,bash_man,bash_mean)values(" "," ");
